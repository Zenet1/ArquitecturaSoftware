var searchData=
[
  ['controllers_0',['Controllers',['../namespace_app_1_1_http_1_1_controllers.html',1,'App::Http']]]
];
