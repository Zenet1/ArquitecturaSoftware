var searchData=
[
  ['_24uri_0',['$uri',['../server_8php.html#a653b5458163d338546c47271b4fb81b7',1,'server.php']]]
];
