var indexSectionsWithContent =
{
  0: "_acdehisu",
  1: "ceh",
  2: "a",
  3: "ceh",
  4: "_cdeisu"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions"
};

var indexSectionLabels =
{
  0: "Todo",
  1: "Estructuras de Datos",
  2: "Namespaces",
  3: "Archivos",
  4: "Funciones"
};

