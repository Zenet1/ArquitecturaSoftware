var searchData=
[
  ['homecontroller_0',['HomeController',['../class_app_1_1_http_1_1_controllers_1_1_home_controller.html',1,'App::Http::Controllers']]]
];
