@mainpage CRUD Laravel - Proyecto Final Arquitecturas de Software

@section Integrantes

   *    Eduardo Zenet Lopez Guerrero
  
   *    David Abraham Paredes Coob

   *    Julian Alejandro Pérez Koo
 