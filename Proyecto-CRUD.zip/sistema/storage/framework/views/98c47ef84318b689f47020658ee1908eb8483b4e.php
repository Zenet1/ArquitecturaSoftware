


<?php $__env->startSection('content'); ?>

<div class="container">


    <?php if(Session::has('mensaje')): ?>
    <div class="alert alert-success alert-dismissible" role="alert">
    <?php echo e(Session::get('mensaje')); ?>

    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
    </button>
    </div>
    <?php endif; ?>
<a href="<?php echo e(url('empleado/create')); ?>" class="btn btn-success"><i class="fas fa-user-plus"></i> Registrar nuevo empleado. </a>
<form method="post">
    <?php echo csrf_field(); ?>
    <?php echo e(method_field('DELETE')); ?>

    
<br>
<table class="table table-hover">
    <thead class="thead-light">
        <tr>
            <th><input type="checkbox" class="selectall"></th>
            <th>ID</th>
            <th>Foto</th>
            <th>Nombre</th>
            <th>Apellido Paterno</th>
            <th>Apellido Materno</th>
            <th>Correo</th>
            <th>Acciones</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $empleados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empleado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><input type="checkbox" name="ids[]" class="selectbox" value="<?php echo e($empleado->id); ?>"></td>
            <td><?php echo e($empleado->id); ?></td>
            <td><img class="img-thumbnail img-fluid" src="<?php echo e(asset('storage').'/'.$empleado->Foto); ?>" alt="foto" width="100"></td>
            <td><?php echo e($empleado->Nombre); ?></td>
            <td><?php echo e($empleado->ApellidoPaterno); ?></td>
            <td><?php echo e($empleado->ApellidoMaterno); ?></td>
            <td><?php echo e($empleado->Correo); ?></td>
            <td><a href="<?php echo e(url('/empleado/'.$empleado->id.'/edit')); ?>" class="btn btn-warning"><i class="fas fa-user-edit"></i></a>  

                <form action="<?php echo e(url('/empleado/'.$empleado->id)); ?>" class="d-inline" method="post">
                <?php echo csrf_field(); ?>
                <?php echo e(method_field('DELETE')); ?>

                
                <button type="submit" class="btn btn-danger" onclick="return confirm('El empleado se borrara')" >
                <i class='fas fa-user-minus'></i>
                </button>
                </form>

            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
    </tbody>
</table>
</form>
<?php echo $empleados->links(); ?>


<script type="text/javascript">
    $('.selectall').click(function(){  
        $('.selectbox').prop('checked',$(this).prop('checked'));
        $('.selectall').prop('checked',$(this).prop('checked'));
    });

    $('.selectbox').change(function(){ 
        var total = $('.selectbox').length;
        var number = $('.selectbox:checked').length;
        if(total == number){
            $('.selectall').prop('checked',true);
        }else{
            $('.selectall').prop('checked',false);
        }
        
    });
</script>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sistema\resources\views/empleado/index.blade.php ENDPATH**/ ?>